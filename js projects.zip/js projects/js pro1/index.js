const input = document.getElementById("numOfwords");
const container = document.querySelector(".container");


let numOfwords
const getData = ()=>{
    numOfwords= Number(input.value);

    const para = document.createElement("p");
    para.innerText= "sample para";
    para.setAttribute("class","paras");
    container.append(para)
};